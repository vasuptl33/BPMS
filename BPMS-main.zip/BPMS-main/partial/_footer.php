<footer id="footer">
    <div class="container py-5">
        <div class="row">
            <div class="col-12 col-md-3">
                <img src="images/MSUB_Logo.png" class="img-fluid" style="background-color: white;" alt="logo">
            </div>
            <div class="col-12 col-md-3 text-light text-center">
                <h5 style="color:white">Address</h5>
                <p>
                    3-6-747/1/A and 3-6-754/1,
                    Himayatnagar, Hyderabad
                    500 029</p>
            </div>
            <div class="col-12 col-md-6 text-light text-center">
                <h5 style="color:white">Contacts</h5>
                <p>
                    Email: info@universitiespress.com<br>
                    Phone: (040) 27662849, 27662850</p>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <hr style="background-color: white;">
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <p style="display: block;color:white;text-align:center">Copyright © Baroda University Press (India) Pvt. Ltd., All rights reserved.</p>
            </div>
        </div>
    </div>
</footer>